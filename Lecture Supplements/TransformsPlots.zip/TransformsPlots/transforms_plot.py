import numpy as np
import scipy as sp
import transform3d
import matplotlib.pyplot as plt


#PLOTR Plot the columns of a 3x3 rotation matrix
#   R - The rotation matrix
#   colorspec - (Optional) A list strings or vectors representing the axes colors.
def plotr (R, colorspec=['r','g','b']):

    plt.plot([0, R[0,0]], [0, R[1,0]], [0, R[2,0]], color=colorspec[0])
    plt.plot([0, R[0,1]], [0, R[1,1]], [0, R[2,1]], color=colorspec[1])
    plt.plot([0, R[0,2]], [0, R[1,2]], [0, R[2,2]], color=colorspec[2])
    
    #plot3 ([0 R(1,1)], [0 R(2,1)], [0 R(3,1)], colorspec{1})
    #plot3 ([0 R(1,2)], [0 R(2,2)], [0 R(3,2)], colorspec{2})
    #plot3 ([0 R(1,3)], [0 R(2,3)], [0 R(3,3)], colorspec{3})
    
    #xlabel('X-axis');
    #ylabel('Y-axis');
    #zlabel('Z-axis');

# PLOTP3 Plots a point 
#   p - The point
#   colorspec - (Optional) A strings or vectors representing the point color.
def plotp3 (p, colorspec='b', marker='.'):    
    plt.plot (p[0], p[1], p[2], color=colorspec, marker=marker)

# PLOTP4 Plots a homogeneous representation of a point 
#   p - The point
#   colorspec - (Optional) A strings or vectors representing the point color.  
def plotp4 (p, colorspec='b', marker='.'):

    plotp3(p[0:3], colorspec=colorspec, marker=marker)


# PLOTFV3 Plots a free vector define from p1 to p2, at the origin  
#   p1 - The from point
#   p2 - The to point
#   colorspec - (Optional) A strings or vectors representing the point color.    
def plotfv3 (p1, p2, colorspec='b'):

    plt.plot([0, p2[0]-p1[0]], [0, p2[1]-p1[1]], [0, p2[2]-p1[2]], color=colorspec)    

# PLOTFV4 Plots a free vector defined using homogeneous points from p1 to p2, at the origin  
#   p1 - The from point
#   p2 - The to point
#   colorspec - (Optional) A strings or vectors representing the point color.    
def plotfv3 (p1, p2, colorspec='b'):

    plotfv3(p1[0:3],p2[0:3], colorspec)

# PLOTV3 Plots a vector defined from p1 to p2
#   p1 - The from point
#   p2 - The to point
#   colorspec - (Optional) A strings or vectors representing the point color.    
def plotv3 (p1, p2, colorspec='b'):

    plt.plot([p1[0],p2[0]], [p1[1],p2[1]], [p1[2],p2[2]], color=colorspec)    


# PLOTV4 Plots a vector defined using homogeneous points from p1 to p2
#   p1 - The from point
#   p2 - The to point
#   colorspec - (Optional) A strings or vectors representing the point color.
def plotv4 (p1, p2, colorspec='b'):    
    
    plotv3 (p1[0:3], p2[0:3], colorspec)

# PLOTF Plot the a frame defined by a rotation and translation
#   H - The frame represented by a homogeneous transform
#   colorspec - (Optional) A cell array of strings or vectors representing the axes colors.
def plotf (H, colorspec=['r','g','b']):
    
    # Extract the rotation and translation
    R = H[0:3,0:3]
    T = H[0:3,3]
    
    plotv3(T, T+R[:,0],colorspec=colorspec[0])
    plotv3(T, T+R[:,1],colorspec=colorspec[1])
    plotv3(T, T+R[:,2],colorspec=colorspec[2])