# Standard imports for having access to numpy, scipi, and matplotlib
import numpy as np
import scipy as sp
import matplotlib.pyplot as plt

# Standard imports for the ROS Client Library (rcl)
import rclpy
from rclpy.node import Node

# Imports for each of the messages that will be used by the node.
from std_msgs.msg import String
from geometry_msgs.msg import Pose

# Declare a new class. The "(Node)" indicates that this class derives from the ROS Node class
class Scrambler(Node):

    # Every class should have an __init__ function, which is the constructor.
    # This gets called each time a new variable of this type is created
    def __init__(self):
        # When your class is derived from another class, you should alway call the parent/super
        #  class's __init__ function also
        super().__init__('Scrambler')
        
        self.publisher_ = self.create_publisher(String, 'Scrambled', 1)
        self.subscriber = self.create_subscription(String, 'Raw', self.on_raw_topic_received,1)

    def on_raw_topic_received(self, in_msg):
        pass

        out_msg = String()
        
        self.get_logger().info(f'Scrambling: {in_msg.data}')
        out_msg.data = in_msg.data[::-1]

        self.get_logger().info(f'Publishing scrambled message: {out_msg.data}')
        self.publisher_.publish(out_msg)


if __name__ == '__main__':
    rclpy.init()

    scrambler_node = Scrambler()

    rclpy.spin(scrambler_node)

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    scrambler_node.destroy_node()
    rclpy.shutdown()
