# Standard imports for having access to numpy, scipi, and matplotlib
import numpy as np
import scipy as sp
import matplotlib.pyplot as plt

# Standard imports for the ROS Client Library (rcl)
import rclpy
from rclpy.node import Node

# Imports for each of the messages that will be used by the node.
from std_msgs.msg import String
from geometry_msgs.msg import Pose

import time

# Declare a new class. The "(Node)" indicates that this class derives from the ROS Node class
class Sender(Node):

    # I can declare a variable outside of a function, but still inside the "scope" of the class.
    # Remember that scope is defines by indentation after a colon
    # If I want to access this variable inside one of the class functions, you need to access it
    #    using "self.message_template"
    message_template = 'Hello world: '

    # Every class should have an __init__ function, which is the constructor.
    # This gets called each time a new variable of this type is created
    def __init__(self):
        # When your class is derived from another class, you should alway call the parent/super
        #  class's __init__ function also
        super().__init__('Sender')
        
        # This creates a class variable that is a ROS publisher. Because we derived this class
        # from the ROS Node class, it has access to class functions declared in the parent
        # class, like create_publisher.
        # The first parameter is the message type that this publisher will send.
        # The second parameter is the name of the topic.
        # The third parameters is the queue size, in case you are publishing very quickly and need
        #  them to be able to queue.
        self.publisher_ = self.create_publisher(String, 'Raw', 1)

        # This code creates a timer that will be executed every 0.5 seconds.
        # It uses a class function from the Node class called create_timer.
        #  The first parameter is the period in seconds
        #  The second parameter is the function that will be called each time the timer triggers.
        timer_period = 0.5  # seconds
        self.timer = self.create_timer(timer_period, self.timer_callback)

    # This is the class function we are going to use to send a message out on the publisher
    def timer_callback(self):
        
        # Create an empty String message
        msg = String()

        # Create the message and publish it.
        msg.data = f'Hello World: {time.time()}'
        self.publisher_.publish(msg)
        self.get_logger().info(f'Publishing raw message: {msg.data}')


if __name__ == '__main__':
    rclpy.init()

    sender_node = Sender()

    rclpy.spin(sender_node)

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    sender_node.destroy_node()
    rclpy.shutdown()
