# Standard imports for having access to numpy, scipi, and matplotlib
import time
import numpy as np
import scipy as sp
import matplotlib.pyplot as plt
import matplotlib.patches as patches


# Standard imports for the ROS Client Library (rcl)
import rclpy
from rclpy.node import Node

# Imports for each of the messages that will be used by the node.
from std_msgs.msg import String
from geometry_msgs.msg import Pose
from geometry_msgs.msg import Twist

# Declare a new class. The "(Node)" indicates that this class derives from the ROS Node class
class RobotSimulator(Node):

    x = 0   # position in x
    y = 0   # position in y
    r = 0   # angular position about z axis

    deltaT = 0.01   # Time step of the euler integration
    dxdt = 0        # linear velocity in x
    dydt = 0        # linear velocity in y
    drdt = 0        # angular velocity about z

    # Every class should have an __init__ function, which is the constructor.
    # This gets called each time a new variable of this type is created
    def __init__(self, fig, ax):
        # When your class is derived from another class, you should alway call the parent/super
        #  class's __init__ function also
        super().__init__('RobotSimulator')
        
        self.publisher_ = self.create_publisher(Pose, 'pose', 1)
        self.subscriber = self.create_subscription(Twist, 'cmd_vel', self.on_cmd_vel_received,1)

        self.fig = fig
        self.ax = ax

        timer_period = self.deltaT  # seconds
        self.timer = self.create_timer(timer_period, self.euler_integration_callback)

    def on_cmd_vel_received(self, msg:Twist):

        # Whenever a new velocity comes in, we store it internally for
        # used on the next iteration of the euler integration
        self.dxdt = msg.linear.x
        self.dydt = msg.linear.y
        self.drdt = msg.angular.z
        
    def euler_integration_callback(self):

        # Peform the Euler integration
        self.x = self.x + self.dxdt * self.deltaT
        self.y = self.y + self.dydt * self.deltaT
        self.r = self.r + self.drdt * self.deltaT

        # Create points to that we can show the orientation of the robot also
        r = 1
        src = [self.x, self.y]
        dst = [self.x+r*np.cos(self.r), self.y+np.sin(self.r)]

        # draw the updated pose
        self.ax.cla()
        circle = patches.Circle((self.x, self.y), r, color='red', fill=False)
        self.ax.add_patch(circle)
        # self.ax.plot(self.x,self.y,'ro')
        
        self.ax.plot([src[0],dst[0]],[src[1],dst[1]],'r')

        self.ax.set_xlim([-10,10])
        self.ax.set_ylim([-10,10])

    def run_node_loop(self):

        # you need this line in there to let it do all the work of sending/receive messages and services
        rclpy.spin_once(self)

        # We put this here so that the actual drawing operation is taken care of on the main thread
        plt.draw()
        plt.pause(0.1)

        # NOTE: Could add other stuff that I want to run on the main thread.
        # ...

        out_msg = Pose()
        out_msg.position.x = self.x
        out_msg.position.y = self.y
        out_msg.orientation.z = self.r
        self.publisher_.publish(out_msg)


if __name__ == '__main__':

    # Creates a new Matplotlib plot
    fig, ax = plt.subplots()

    # Puts Matplotlib in interactive mode so that the plt.show() doesn't block execution
    plt.ion()
    plt.show()

    plt.draw()
    plt.pause(1)

    rclpy.init()

    robot_simulator_node = RobotSimulator(fig,ax)

    # NEW WAY OF RUNNING THE NODE'S run_node_loop FUNCTION MANUALLY
    start_time = time.time()
    while True:
        robot_simulator_node.run_node_loop()
        time.sleep(0.001)

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    robot_simulator_node.destroy_node()
    rclpy.shutdown()
