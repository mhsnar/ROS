# Standard imports for having access to numpy, scipi, and matplotlib
import numpy as np
import scipy as sp
import matplotlib.pyplot as plt
from transform3d import Transform

# Standard imports for the ROS Client Library (rcl)
import rclpy
from rclpy.node import Node

# Imports for each of the messages that will be used by the node.
from std_msgs.msg import String
from geometry_msgs.msg import Pose
from geometry_msgs.msg import Twist

import time

# Declare a new class. The "(Node)" indicates that this class derives from the ROS Node class
class Controller(Node):

    # Every class should have an __init__ function, which is the constructor.
    # This gets called each time a new variable of this type is created
    def __init__(self):
        # When your class is derived from another class, you should alway call the parent/super
        #  class's __init__ function also
        super().__init__('Controller')
        
        self.publisher_ = self.create_publisher(Twist, 'cmd_vel', 1)
        self.subscriber = self.create_subscription(Pose,'pose',self.on_pose_received,1)


        # This code creates a timer that will be executed every 0.5 seconds.
        # It uses a class function from the Node class called create_timer.
        #  The first parameter is the period in seconds
        #  The second parameter is the function that will be called each time the timer triggers.
        timer_period = 3  # seconds
        self.timer = self.create_timer(timer_period, self.timer_callback)

    def on_pose_received(self,msg:Pose):
        print(f'Pose received: {msg.position.x}, {msg.position.y}, {msg.orientation.z}')

        poseTF = Transform(p=[msg.position.x,msg.position.y,msg.position.z],
                           quat=[msg.orientation.x,msg.orientation.y,msg.orientation.z,msg.orientation.w])
        
        


    # This is the class function we are going to use to send a message out on the publisher
    def timer_callback(self):
        
        # Create a Pose message and fill it with random velocities
        # because this updates once every 3 seconds, the robot kindof
        # just wanders around
        msg = Twist()
        msg.linear.x = np.random.uniform(-5,5)
        msg.linear.y = np.random.uniform(-5,5)
        msg.angular.z = np.random.uniform(-np.pi,np.pi)


        # Create the message and publish it.
        self.publisher_.publish(msg)


if __name__ == '__main__':
    rclpy.init()

    controller_node = Controller()

    rclpy.spin(controller_node)

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    controller_node.destroy_node()
    rclpy.shutdown()
