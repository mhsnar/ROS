# Standard imports for having access to numpy, scipi, and matplotlib
import time
import numpy as np
import scipy as sp
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from transform3d import Transform
from typing import List

# Standard imports for the ROS Client Library (rcl)
import rclpy
from rclpy.node import Node

# Imports for each of the messages that will be used by the node.
from std_msgs.msg import String
from geometry_msgs.msg import Twist

from turtlesim.msg import Pose
from turtlesim.srv import Spawn
from turtlesim.srv import SetPen


class Waypoint:
    pen_off = True
    pen_rgb = [255,255,255]
    pen_width = 1
    target = [0,0]

    def __init__(self,target,pen_off=False,pen_rgb=[255,255,255],pen_width=1) -> None:
        self.pen_off = pen_off
        self.pen_rgb = pen_rgb
        self.pen_width = pen_width
        self.target = target

class TurtlebotController(Node):

    Kp_angle = 6
    Kp_linear = 2
    thresh = 0.1
    waypoints:List[Waypoint] = []
    pose = None

    def __init__(self, turtle_name, waypoints):
        super().__init__(f'TurtlebotController_{turtle_name}')
        
        self.turtle_name = turtle_name

        # Create the publisher and subscriber
        self.publisher_ = self.create_publisher(Twist, f'/{turtle_name}/cmd_vel', 1)
        self.subscriber = self.create_subscription(Pose,f'/{turtle_name}/pose',self.on_pose_received,1)

        # Create both the service client and the request object for set_pen service
        self.setpen_service_client = self.create_client(SetPen, f'/{turtle_name}/set_pen')
        while not self.setpen_service_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('service not available, waiting again...')
        self.setpen_request = SetPen.Request()

        self.waypoints = waypoints
        self.idx = 0

        timer_period = 0.001  # seconds
        self.timer = self.create_timer(timer_period, self.timer_callback)

    def on_pose_received(self,msg:Pose):
        # store the pose once it is received
        self.x = msg.x
        self.y = msg.y
        self.theta = msg.theta
        self.pose = Transform(p=[msg.x,msg.y,0],rotvec=[0,0,msg.theta])

    def compute_desired_velocity(self, target_w):
        pass

        # Make a 3D version of the target point with Z=0
        p_w = [target_w[0],target_w[1],0]
        # Convert into the robot coordinate frame
        p_r = self.pose.inv @ p_w
        
        # Use the arctan (and in particular the quadrant-aware arctan2) function to find the angle relative
        # to the body-fixed coordinate frame of the robot
        angle_r = np.arctan2(p_r[1],p_r[0])
        dr = self.Kp_angle * angle_r

        # Use the magnitude of the distance to the target as the means of finding velocity
        distance = np.linalg.norm(p_r)
        dx = self.Kp_linear * distance

        
        return (dx,dr)

    # This is the class function we are going to use to send a message out on the publisher
    def timer_callback(self):
        
        
        # Get the current action and determine if we should go to the next action
        if self.idx >= len(self.waypoints) or self.pose is None:
            return
    
        waypoint = self.waypoints[self.idx]
        target = waypoint.target

        # Check if we are currently near enough the waypoint end. If we are, go to the next target
        p_w = np.array([target[0],target[1],0])
        if np.linalg.norm(self.pose.p-p_w) < self.thresh:
            self.idx += 1
            return


        # Create the message.
        msg = Twist()
        # Compute the desired velocities using the controller
        dx,dr = self.compute_desired_velocity(target)
        msg.linear.x = dx
        msg.angular.z = dr
        # Publish the message
        self.publisher_.publish(msg)

        # Fill in the set_pen service request and call the service
        self.setpen_request.off = waypoint.pen_off
        self.setpen_request.r = waypoint.pen_rgb[0]
        self.setpen_request.g = waypoint.pen_rgb[1]
        self.setpen_request.b = waypoint.pen_rgb[2]
        self.setpen_request.width = waypoint.pen_width
        self.future = self.setpen_service_client.call_async(self.setpen_request)


if __name__ == '__main__':
    pass
