# Standard imports for having access to numpy, scipi, and matplotlib
import time
import numpy as np
import scipy as sp
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from transform3d import Transform
from typing import List

# Standard imports for the ROS Client Library (rcl)
import rclpy
from rclpy.node import Node

# Imports for each of the messages that will be used by the node.
from std_msgs.msg import String
from geometry_msgs.msg import Twist

from turtlesim.msg import Pose
from turtlesim.srv import Spawn
from turtlesim.srv import SetPen

from RobotController import Waypoint, TurtlebotController

def create_head_waypoints(radius, numpoints):
    pass
    rv = []

    cx = 5
    cy = 5
    for angle in np.arange(0,1.2*np.pi*2,np.pi*2.0/numpoints):
        x = cx+radius*np.cos(angle)
        y = cy+radius*np.sin(angle)

        if len(rv) == 0:
            pen_off = True
        else:
            pen_off = False
        
        color = [204,204,0]
        pen_width = 3

        wp = Waypoint([x,y], pen_off, color, pen_width)
        rv.append(wp)
    
    return rv

def create_mouth_waypoints(radius, numpoints):
    pass
    rv = []

    cx = 5
    cy = 5
    for angle in np.arange(np.pi,2*np.pi,np.pi/numpoints):
        x = cx+radius*np.cos(angle)
        y = cy+radius*np.sin(angle)

        if len(rv) == 0:
            pen_off = True
        else:
            pen_off = False
        
        color = [255,0,0]
        pen_width = 3

        wp = Waypoint([x,y], pen_off, color, pen_width)
        rv.append(wp)
    
    return rv

if __name__ == '__main__':

    rclpy.init()

    # Call the functions to create the individual paths
    head_waypoints:List[Waypoint] = create_head_waypoints(3.75, 30)
    mouth_waypoints:List[Waypoint] = create_mouth_waypoints(2.75, 10)   

    # Combine the two lists
    head_mouth_waypoints:List[Waypoint] = head_waypoints + mouth_waypoints

    controller_node = TurtlebotController('turtle1',head_mouth_waypoints)

    rclpy.spin(controller_node)

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    controller_node.destroy_node()
    rclpy.shutdown()
