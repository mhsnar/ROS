# Standard imports for having access to numpy, scipi, and matplotlib
import time
import numpy as np
import scipy as sp
import matplotlib.pyplot as plt
import matplotlib.patches as patches


# Standard imports for the ROS Client Library (rcl)
import rclpy
from rclpy.node import Node

# Imports for each of the messages that will be used by the node.
from std_msgs.msg import String
from geometry_msgs.msg import Twist

from turtlesim.msg import Pose
from turtlesim.srv import Spawn
from turtlesim.srv import SetPen


if __name__ == '__main__':

    rclpy.init()

    node = rclpy.create_node('spawn_second_turtle')

    spawn_client = node.create_client(Spawn, '/spawn')
    while not spawn_client.wait_for_service(timeout_sec=1.0):
        print('Waiting for service...')
    spawn_request = Spawn.Request()
    spawn_request.name = 'turtle2'
    spawn_request.x = 5.0
    spawn_request.y = 5.0
    spawn_request.theta = np.pi

    response = spawn_client.call_async(spawn_request)
    print(response)

    node.destroy_node()
    rclpy.shutdown()


