# Standard imports for having access to numpy, scipi, and matplotlib
import time
import numpy as np
import scipy as sp
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from transform3d import Transform
from typing import List

# Standard imports for the ROS Client Library (rcl)
import rclpy
from rclpy.node import Node

# Imports for each of the messages that will be used by the node.
from std_msgs.msg import String
from geometry_msgs.msg import Twist

from turtlesim.msg import Pose
from turtlesim.srv import Spawn
from turtlesim.srv import SetPen

from RobotController import Waypoint, TurtlebotController

def create_eye_waypoints(radius, numpoints, cx, cy):
    pass
    rv = []

    for angle in np.arange(0,1.2*np.pi*2,np.pi*2.0/numpoints):
        x = cx+radius*np.cos(angle)
        y = cy+radius*np.sin(angle)

        if len(rv) == 0:
            pen_off = True
        else:
            pen_off = False
        
        color = [0,0,0]
        pen_width = 3

        wp = Waypoint([x,y], pen_off, color, pen_width)
        rv.append(wp)
    
    return rv

def create_nose_waypoints(radius, numpoints):
    pass
    rv = []

    cx = 5
    cy = 4.5
    for angle in np.arange(np.pi,2*np.pi,np.pi/numpoints):
        x = cx+radius*np.cos(angle)
        y = cy+radius*np.sin(angle)

        if len(rv) == 0:
            pen_off = True
        else:
            pen_off = False
        
        color = [51,204,51]
        pen_width = 3

        wp = Waypoint([x,y], pen_off, color, pen_width)
        rv.append(wp)
    
    return rv

if __name__ == '__main__':

    rclpy.init()

    # Call the functions to create the individual paths
    lefteye_waypoints:List[Waypoint] = create_eye_waypoints(0.75, 30, 4.25, 6)
    righteye_waypoints:List[Waypoint] = create_eye_waypoints(0.75, 30, 6.25, 6)
    nose_waypoints:List[Waypoint] = create_nose_waypoints(1.0, 10)   

    # Combine the two lists
    eyes_nose_waypoints:List[Waypoint] = righteye_waypoints + nose_waypoints + lefteye_waypoints

    controller_node = TurtlebotController('turtle2',eyes_nose_waypoints)

    rclpy.spin(controller_node)

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    controller_node.destroy_node()
    rclpy.shutdown()
